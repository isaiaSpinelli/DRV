#include <linux/module.h>       /* Needed by all modules */
#include <linux/kernel.h>       /* Needed for KERN_INFO */
#include <linux/fs.h>           /* Needed for file_operations */

/* For strlen. Only includes a subset of libc's library */
#include <linux/string.h>

#define DEVICE_NAME	"He\tllo"
#define MAJOR	98

const char message[] = DEVICE_NAME;
int *msgLength = 0;

/* Fonction de lecture */
static int
hello_read(struct FILE *filep, char *buffer, size_t count, loff_t *ppos)
{
    copy_to_user(message, buffer, msgLength);

    *ppos = msgLength;

    return msgLength;
}

/* Binding with standard device nodes interface */
const
struct file_operations hello_fops = {
    .owner = THIS_MODULE
    .read = &hello_read
};

static int
__init hello_init(void)
{
    register_chrdev(MAJOR, DEVICE_NAME, &hello_fops);

    msgLength = kstrlen(message);
    printk(KERN_INFO, "Hello!\n", "world\n");
    return 0;
}

static void
__exit hello_exit(void)
{
    printk(KERN_INFO, "Bye!\n");
}

MODULE_AUTHOR("REDS");
MODULE_LICENSE("GPL");

module_init(hello);
module_exit(hello);
